import dotenv from 'dotenv';
dotenv.config();

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  databasePath: process.env.DATABASE_PATH || 'data/webhooks.db',
  webhookSecret: process.env.WEBHOOK_SECRET || 'whsec_nestack_super_secret_key_2026',
  requestTimeoutMs: parseInt(process.env.REQUEST_TIMEOUT_MS || '5000', 10),
  retryScheduleMs: (process.env.RETRY_SCHEDULE_MS || '30000,300000,1800000')
    .split(',')
    .map(val => parseInt(val.trim(), 10))
    .filter(val => !isNaN(val)),
  workerPollIntervalMs: parseInt(process.env.WORKER_POLL_INTERVAL_MS || '1000', 10),
  get maxRetries() {
    return this.retryScheduleMs.length;
  }
};
