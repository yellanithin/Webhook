import express from 'express';
import { createEventsRouter } from './routes/events.js';

/**
 * Creates and configures the Express application.
 *
 * @param {Object} options
 * @param {import('./db/repository.js').EventRepository} options.repository
 * @param {import('./services/deliveryEngine.js').DeliveryEngine} [options.deliveryEngine]
 * @returns {express.Express}
 */
export function createApp({ repository, deliveryEngine }) {
  const app = express();

  app.use(express.json());

  // Health check endpoint
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', uptime: process.uptime() });
  });

  // Mount events router
  const eventsRouter = createEventsRouter({ repository, deliveryEngine });
  app.use('/', eventsRouter);

  // 404 handler for unknown routes
  app.use((req, res) => {
    res.status(404).json({ error: 'Endpoint not found' });
  });

  // Global error handler
  app.use((err, req, res, next) => {
    if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
      return res.status(400).json({ error: 'Malformed JSON payload in request body' });
    }
    console.error('Unhandled server error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  });

  return app;
}
