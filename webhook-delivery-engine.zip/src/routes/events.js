import { Router } from 'express';

/**
 * Creates the events router.
 *
 * @param {Object} options
 * @param {import('../db/repository.js').EventRepository} options.repository
 * @param {import('../services/deliveryEngine.js').DeliveryEngine} [options.deliveryEngine]
 * @returns {Router}
 */
export function createEventsRouter({ repository, deliveryEngine }) {
  const router = Router();

  // POST /events - Ingest a new webhook event
  router.post('/events', (req, res) => {
    const { type, payload, webhook_url } = req.body || {};

    // Validate inputs
    if (!type || typeof type !== 'string' || type.trim().length === 0) {
      return res.status(400).json({ error: 'Field "type" must be a non-empty string' });
    }

    if (payload === undefined || payload === null) {
      return res.status(400).json({ error: 'Field "payload" is required' });
    }

    if (!webhook_url || typeof webhook_url !== 'string') {
      return res.status(400).json({ error: 'Field "webhook_url" must be a valid URL string' });
    }

    try {
      const parsedUrl = new URL(webhook_url);
      if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
        return res.status(400).json({ error: 'Field "webhook_url" must use http or https protocol' });
      }
    } catch {
      return res.status(400).json({ error: 'Field "webhook_url" is not a valid URL' });
    }

    const event = repository.createEvent({
      type: type.trim(),
      payload,
      webhook_url
    });

    // Attempt delivery immediately as soon as ingested
    if (deliveryEngine) {
      deliveryEngine.wakeUp();
    }

    return res.status(201).json(event);
  });

  // GET /events - List all events
  router.get('/events', (req, res) => {
    const events = repository.listEvents();
    return res.status(200).json(events);
  });

  // GET /events/:id - Get a single event with attempt history
  router.get('/events/:id', (req, res) => {
    const { id } = req.params;
    const event = repository.getEventById(id);

    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }

    return res.status(200).json(event);
  });

  // POST /events/:id/retry - Manually trigger retry for a dead event
  router.post('/events/:id/retry', (req, res) => {
    const { id } = req.params;
    const result = repository.requeueDeadEvent(id);

    if (!result.success) {
      if (result.error === 'not_found') {
        return res.status(404).json({ error: 'Event not found' });
      }
      if (result.error === 'not_dead') {
        return res.status(400).json({ error: 'Only dead events can be retried' });
      }
      return res.status(400).json({ error: 'Failed to re-queue event' });
    }

    // Trigger immediate delivery attempt
    if (deliveryEngine) {
      deliveryEngine.wakeUp();
    }

    return res.status(200).json(result.event);
  });

  return router;
}
