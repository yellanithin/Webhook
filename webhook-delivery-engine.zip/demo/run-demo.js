import http from 'node:http';
import { initDatabase } from '../src/db/database.js';
import { EventRepository } from '../src/db/repository.js';
import { DeliveryEngine } from '../src/services/deliveryEngine.js';
import { createApp } from '../src/app.js';
import { verifySignature } from '../src/services/signature.js';

const SECRET = 'whsec_demo_secret_2026';

async function main() {
  console.log('===============================================================');
  console.log('   NESTACK WEBHOOK DELIVERY ENGINE - END-TO-END DEMONSTRATION  ');
  console.log('===============================================================\n');

  let receiverMode = 'success';
  const receiverHistory = [];

  // 1. Start mock receiver
  const receiverServer = http.createServer((req, res) => {
    let rawBody = '';
    req.on('data', chunk => { rawBody += chunk; });
    req.on('end', () => {
      const sig = req.headers['x-webhook-signature'];
      const valid = verifySignature(rawBody, sig, SECRET);
      const parsed = JSON.parse(rawBody);

      receiverHistory.push({
        eventId: parsed.id,
        type: parsed.type,
        valid,
        mode: receiverMode
      });

      if (receiverMode === 'fail') {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Receiver simulated failure' }));
      } else {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'received', verified: valid }));
      }
    });
  });

  const receiverPort = await new Promise(resolve => {
    receiverServer.listen(0, () => resolve(receiverServer.address().port));
  });
  const receiverUrl = `http://127.0.0.1:${receiverPort}/webhook`;
  console.log(`[1] Mock Webhook Destination running at: ${receiverUrl}`);

  // 2. Start delivery engine and API server
  const db = initDatabase(':memory:');
  const repository = new EventRepository(db);

  // Fast retry schedule for demo: 100ms -> 200ms -> 300ms
  const engine = new DeliveryEngine({
    repository,
    secret: SECRET,
    retryScheduleMs: [150, 300, 450],
    requestTimeoutMs: 1000,
    pollIntervalMs: 50
  });
  engine.start();

  const app = createApp({ repository, deliveryEngine: engine });
  const server = await new Promise(resolve => {
    const s = app.listen(0, () => resolve(s));
  });
  const apiBase = `http://127.0.0.1:${server.address().port}`;
  console.log(`[2] Webhook API Server running at: ${apiBase}`);

  try {
    // SCENARIO 1: Immediate Successful Delivery
    console.log('\n--- SCENARIO 1: Ingesting Event with Immediate Successful Delivery ---');
    receiverMode = 'success';

    const res1 = await fetch(`${apiBase}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'payment.success',
        payload: { order_id: 'ord_101', amount: 1500, currency: 'USD' },
        webhook_url: receiverUrl
      })
    });

    const event1 = await res1.json();
    console.log(`Ingested event 1 (ID: ${event1.id}), initial status: ${event1.status}`);

    // Wait for delivery
    await new Promise(r => setTimeout(r, 200));
    const inspect1 = await (await fetch(`${apiBase}/events/${event1.id}`)).json();
    console.log(`Delivered status: ${inspect1.status}`);
    console.log(`Attempt history:`, JSON.stringify(inspect1.attempts, null, 2));

    // SCENARIO 2: Failing Delivery & Complete Retry Schedule (30s -> 5m -> 30m -> Dead)
    console.log('\n--- SCENARIO 2: Ingesting Event That Fails and Progresses to DEAD ---');
    receiverMode = 'fail';

    const res2 = await fetch(`${apiBase}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'user.signup',
        payload: { user_id: 'usr_888', plan: 'enterprise' },
        webhook_url: receiverUrl
      })
    });

    const event2 = await res2.json();
    console.log(`Ingested event 2 (ID: ${event2.id}), initial status: ${event2.status}`);

    // Monitor retry progression
    console.log('Monitoring retry progression through schedule (initial -> retry 1 -> retry 2 -> retry 3 -> dead)...');
    for (let sec = 0; sec < 15; sec++) {
      await new Promise(r => setTimeout(r, 100));
      const current = await (await fetch(`${apiBase}/events/${event2.id}`)).json();
      if (current.status === 'dead') {
        console.log(`Event reached status: ${current.status} with ${current.attempts.length} attempts!`);
        console.log(`Full attempt history:`, JSON.stringify(current.attempts, null, 2));
        break;
      }
    }

    // SCENARIO 3: Manual Retry for Dead Event
    console.log('\n--- SCENARIO 3: Customer Manually Retrying the Dead Event ---');
    receiverMode = 'success'; // Customer endpoint is healthy again!

    const resRetry = await fetch(`${apiBase}/events/${event2.id}/retry`, {
      method: 'POST'
    });
    const requeuedEvent = await resRetry.json();
    console.log(`POST /events/${event2.id}/retry response status: ${resRetry.status}`);
    console.log(`Re-queued event status: ${requeuedEvent.status}`);

    // Wait for delivery to succeed
    await new Promise(r => setTimeout(r, 200));
    const inspectRecovered = await (await fetch(`${apiBase}/events/${event2.id}`)).json();
    console.log(`Final event status after recovery: ${inspectRecovered.status}`);
    console.log(`Total attempts count: ${inspectRecovered.attempts.length}`);
    console.log(`Latest attempt outcome: ${inspectRecovered.attempts[inspectRecovered.attempts.length - 1].outcome} (HTTP ${inspectRecovered.attempts[inspectRecovered.attempts.length - 1].http_status})`);

    // SCENARIO 4: List All Events
    console.log('\n--- SCENARIO 4: Listing All Events (GET /events) ---');
    const allEvents = await (await fetch(`${apiBase}/events`)).json();
    console.log(`Retrieved ${allEvents.length} events from database.`);
    for (const ev of allEvents) {
      console.log(` - ID: ${ev.id} | Type: ${ev.type} | Status: ${ev.status} | Attempts: ${ev.attempts.length}`);
    }

    console.log('\n===============================================================');
    console.log('                  DEMO COMPLETED SUCCESSFULLY!                 ');
    console.log('===============================================================');
  } finally {
    await engine.stop();
    server.close();
    receiverServer.close();
  }
}

main().catch(console.error);
