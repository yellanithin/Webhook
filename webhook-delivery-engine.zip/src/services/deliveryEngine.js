import { sendWebhookRequest } from './httpClient.js';
import { logger } from '../utils/logger.js';

export class DeliveryEngine {
  /**
   * @param {Object} options
   * @param {import('../db/repository.js').EventRepository} options.repository
   * @param {string} options.secret - HMAC secret key
   * @param {number[]} [options.retryScheduleMs] - Schedule intervals e.g. [30000, 300000, 1800000]
   * @param {number} [options.requestTimeoutMs] - HTTP timeout limit
   * @param {number} [options.pollIntervalMs] - Polling interval in ms
   */
  constructor({
    repository,
    secret,
    retryScheduleMs = [30000, 300000, 1800000],
    requestTimeoutMs = 5000,
    pollIntervalMs = 1000
  }) {
    this.repository = repository;
    this.secret = secret;
    this.retryScheduleMs = retryScheduleMs;
    this.maxRetries = retryScheduleMs.length; // 3 retries (4 total attempts)
    this.requestTimeoutMs = requestTimeoutMs;
    this.pollIntervalMs = pollIntervalMs;

    this.isRunning = false;
    this.timer = null;
    this.inFlight = new Set();
    this.isProcessing = false;
  }

  /**
   * Starts the background delivery engine worker.
   */
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    logger.info('Delivery engine started', {
      retryScheduleMs: this.retryScheduleMs,
      maxRetries: this.maxRetries,
      pollIntervalMs: this.pollIntervalMs
    });

    this._scheduleNextTick(0);
  }

  /**
   * Stops the background delivery engine worker gracefully.
   */
  async stop() {
    this.isRunning = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }

    // Wait for any currently in-flight requests to complete
    while (this.inFlight.size > 0 || this.isProcessing) {
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    logger.info('Delivery engine stopped');
  }

  /**
   * Wakes up the worker immediately (e.g. upon event ingestion).
   */
  wakeUp() {
    if (!this.isRunning) return;
    // Clear scheduled timer and run immediately
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    setImmediate(() => this._processDueEvents());
  }

  /**
   * Schedules the next polling tick.
   * @private
   */
  _scheduleNextTick(delayMs = this.pollIntervalMs) {
    if (!this.isRunning) return;
    this.timer = setTimeout(() => {
      this._processDueEvents();
    }, delayMs);
  }

  /**
   * Core processing loop: queries due events and dispatches delivery attempts.
   * @private
   */
  async _processDueEvents() {
    if (this.isProcessing || !this.isRunning) {
      return;
    }

    this.isProcessing = true;
    try {
      const dueEvents = this.repository.getDueEvents(20);

      const tasks = [];
      for (const event of dueEvents) {
        if (!this.inFlight.has(event.id)) {
          tasks.push(this.processEvent(event));
        }
      }

      if (tasks.length > 0) {
        await Promise.allSettled(tasks);
      }
    } catch (err) {
      logger.error('Error in delivery engine processing cycle', { error: err.message });
    } finally {
      this.isProcessing = false;
      if (this.isRunning) {
        this._scheduleNextTick(this.pollIntervalMs);
      }
    }
  }

  /**
   * Delivers a single event and manages status transitions and retry scheduling.
   *
   * @param {Object} event - Event record from database
   */
  async processEvent(event) {
    if (this.inFlight.has(event.id)) {
      return;
    }

    this.inFlight.add(event.id);
    const attemptedAt = new Date().toISOString();

    try {
      // Temporarily bump next_retry_at forward to prevent duplicate pickup
      this.repository.updateEventStatus(event.id, {
        status: event.status,
        retryCount: event.retry_count,
        nextRetryAt: new Date(Date.now() + this.requestTimeoutMs + 5000).toISOString()
      });

      logger.info(`Attempting webhook delivery for event ${event.id} (retry ${event.retry_count})`, {
        url: event.webhook_url,
        type: event.type
      });

      const result = await sendWebhookRequest(event, this.secret, this.requestTimeoutMs);

      // Record this attempt in the database
      this.repository.recordAttempt({
        eventId: event.id,
        attemptedAt,
        httpStatus: result.httpStatus,
        outcome: result.outcome,
        errorMessage: result.errorMessage,
        responseTimeMs: result.responseTimeMs
      });

      if (result.outcome === 'success') {
        // Immediate transition to delivered
        this.repository.updateEventStatus(event.id, {
          status: 'delivered',
          retryCount: event.retry_count,
          nextRetryAt: null
        });
        logger.info(`Webhook delivery SUCCEEDED for event ${event.id}`, {
          httpStatus: result.httpStatus,
          responseTimeMs: result.responseTimeMs
        });
      } else {
        // Delivery failed
        const newRetryCount = (event.retry_count || 0) + 1;

        if (newRetryCount > this.maxRetries) {
          // Three failed retries exhausted (4 total attempts) -> Mark as dead
          this.repository.updateEventStatus(event.id, {
            status: 'dead',
            retryCount: newRetryCount,
            nextRetryAt: null
          });
          logger.warn(`Webhook delivery DEAD for event ${event.id} after ${newRetryCount} failed attempts`, {
            error: result.errorMessage,
            httpStatus: result.httpStatus
          });
        } else {
          // Schedule next retry according to fixed intervals: 30s -> 5m -> 30m
          const delayMs = this.retryScheduleMs[newRetryCount - 1];
          const nextRetryDate = new Date(Date.now() + delayMs);

          this.repository.updateEventStatus(event.id, {
            status: 'failed',
            retryCount: newRetryCount,
            nextRetryAt: nextRetryDate.toISOString()
          });

          logger.warn(`Webhook delivery FAILED for event ${event.id}. Retry #${newRetryCount} scheduled in ${delayMs / 1000}s at ${nextRetryDate.toISOString()}`, {
            error: result.errorMessage,
            httpStatus: result.httpStatus
          });
        }
      }
    } catch (err) {
      logger.error(`Unexpected error processing event ${event.id}`, { error: err.message });
    } finally {
      this.inFlight.delete(event.id);
    }
  }
}
