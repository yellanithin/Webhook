# Webhook Delivery Engine

A robust, self-contained Webhook Delivery Engine built in **Node.js** featuring custom retry scheduling without third-party queue libraries, **HMAC-SHA256** request signing, resilient failure and timeout handling, and persistent SQLite storage.

---

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Key Features](#key-features)
- [Setup & Installation](#setup--installation)
- [How to Run](#how-to-run)
  - [1. Unified Server & Background Worker (Recommended)](#1-unified-server--background-worker-recommended)
  - [2. Standalone Server and Worker Processes](#2-standalone-server-and-worker-processes)
  - [3. Running the Automated Test Suite](#3-running-the-automated-test-suite)
  - [4. Running the End-to-End Demo](#4-running-the-end-to-end-demo)
  - [5. Running the Mock Webhook Receiver](#5-running-the-mock-webhook-receiver)
- [API Reference](#api-reference)
  - [POST /events](#post-events)
  - [GET /events](#get-events)
  - [GET /events/:id](#get-eventsid)
  - [POST /events/:id/retry](#post-eventsidretry)
- [Retry Scheduling Approach](#retry-scheduling-approach)
- [HMAC-SHA256 Signing & Verification](#hmac-sha256-signing--verification)
  - [Verification Example (Node.js)](#verification-example-nodejs)
  - [Verification Example (Python)](#verification-example-python)
- [Server Restart Behavior & In-Progress Retries](#server-restart-behavior--in-progress-retries)
- [Deployment & Submission Notes](#deployment--submission-notes)

---

## Overview

When events occur on a SaaS platform (e.g. `payment.failed`, `user.signup`), customer endpoints must be reliably notified via HTTP webhooks. This system handles the entire lifecycle:
1. **Event Ingestion**: Exposes an API endpoint accepting events and queues them for delivery.
2. **Delivery Engine**: An autonomous background worker reading pending events and attempting delivery immediately, retrying failed deliveries on a strict schedule (**30s &rarr; 5m &rarr; 30m**) until success or marked as `dead` after 3 failed retries (4 total attempts).
3. **Status Visibility**: Allows consumers to list all events, retrieve event histories with detailed attempt logs, and manually retry `dead` events.

---

## Architecture

```
                       +-----------------------+
                       |    Client / SaaS      |
                       +-----------------------+
                                   |
                         POST /events (HTTP)
                                   v
+--------------------------------------------------------------------------+
|                          API Server (Express)                            |
|  - Validates event payload and webhook URL                               |
|  - Persists event as 'pending' with immediate next_retry_at              |
|  - Signals the Background Delivery Worker                                |
+--------------------------------------------------------------------------+
                                   |
                                   v
+--------------------------------------------------------------------------+
|                      SQLite Database (node:sqlite)                       |
|  - Table: events (id, type, payload, webhook_url, status, retry_count,  |
|                   next_retry_at, created_at, updated_at)                 |
|  - Table: attempts (id, event_id, attempt_number, attempted_at,          |
|                     http_status, outcome, error_message, duration_ms)    |
+--------------------------------------------------------------------------+
                                   ^
                                   |
+--------------------------------------------------------------------------+
|            Background Delivery Engine (Self-Implemented Worker)          |
|  - Autonomous polling loop (no Celery, BullMQ, or external queues)       |
|  - Signs outgoing requests with HMAC-SHA256 (X-Webhook-Signature)        |
|  - Configurable timeouts (AbortSignal) and non-2xx failure classification|
|  - Schedule: Immediate -> 30s -> 5m -> 30m -> DEAD                       |
+--------------------------------------------------------------------------+
                                   |
                        Signed HTTP POST Request
                                   v
                       +-----------------------+
                       |  Customer Webhook URL |
                       +-----------------------+
```

---

## Key Features

- **No Third-Party Queue Libraries**: Zero dependency on Redis, Celery, BullMQ, RQ, or Bee-Queue. Retry scheduling is implemented natively using SQLite query scheduling and atomic state management.
- **Immediate Initial Attempt**: Delivery is triggered as soon as the event is ingested, without waiting for the first retry interval.
- **Strict Fixed Retry Schedule**: `30 seconds` &rarr; `5 minutes` &rarr; `30 minutes`. After 3 failed retries (4 total attempts), status transitions to `dead`.
- **HMAC-SHA256 Signature**: Every outgoing webhook request includes a cryptographically secure signature in the `X-Webhook-Signature` header computed over the raw JSON payload.
- **Resilient Failure Handling**: Non-2xx HTTP response codes, timeouts, and network connectivity errors are cleanly recorded as failures (`http_status: null` on timeout or network error) without crashing the process.
- **Crash & Restart Durability**: Because state and `next_retry_at` timestamps are stored in SQLite (WAL mode), in-progress retries seamlessly resume when the server restarts.

---

## Setup & Installation

### Prerequisites
- **Node.js**: `v20.0.0` or higher (Recommended: `v22` or `v24` with native `node:sqlite` support).
- **npm**: `v9.0.0` or higher.

### 1. Clone or Extract Codebase
```bash
cd webhook-delivery-engine
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment
Copy the example environment configuration:
```bash
cp .env.example .env
```

Default configuration variables (`.env`):
| Variable | Default Value | Description |
|---|---|---|
| `PORT` | `3000` | Port for the HTTP API server |
| `DATABASE_PATH` | `data/webhooks.db` | File path for SQLite database (`:memory:` for in-memory) |
| `WEBHOOK_SECRET` | `whsec_nestack_super_secret_key_2026` | Secret key used for HMAC-SHA256 signatures |
| `REQUEST_TIMEOUT_MS` | `5000` | Outgoing HTTP request timeout limit (ms) |
| `RETRY_SCHEDULE_MS` | `30000,300000,1800000` | Retry intervals in ms: 30s &rarr; 5m &rarr; 30m |
| `WORKER_POLL_INTERVAL_MS` | `1000` | Polling frequency for the delivery engine loop (ms) |

---

## How to Run

### 1. Unified Server & Background Worker (Recommended)
Runs both the Express API server and the background delivery engine concurrently within a single process:
```bash
npm start
```
Output:
```
[INFO] Webhook Delivery Engine running (Server + Background Worker)
[INFO] API Server: http://localhost:3000
[INFO] Database: data/webhooks.db
[INFO] Retry Schedule: 30s -> 300s -> 1800s
```

### 2. Standalone Server and Worker Processes
You can also run the API server and worker as decoupled background processes:

**Terminal 1 (API Server):**
```bash
npm run server
```

**Terminal 2 (Background Delivery Worker):**
```bash
npm run worker
```

### 3. Running the Automated Test Suite
The project includes a comprehensive test suite covering API endpoints, HMAC signatures, delivery execution, and retry failure progression:
```bash
npm test
```
All 25 tests run natively without external test runners:
- Signature generation, tampering detection, and verification
- Event ingestion validation (type, payload, webhook URL format)
- `GET /events` and `GET /events/:id` responses
- Immediate delivery upon ingestion
- Full retry lifecycle transitions (`pending` &rarr; `failed` &rarr; `dead`)
- Timeout handling (`http_status: null`)
- Network errors without crashes
- Dead event re-queuing and recovery

### 4. Running the End-to-End Demo
To see the full lifecycle demonstrated automatically:
```bash
npm run demo
```
This runs an automated simulation that:
1. Spawns a mock webhook destination.
2. Ingests a successful event (`status: delivered`).
3. Ingests an event that fails and progresses through all retry intervals to `dead`.
4. Manually re-queues the dead event via `POST /events/:id/retry` and recovers it.
5. Lists all events and prints the attempts history.

### 5. Running the Mock Webhook Receiver
To manually test outgoing webhooks from your server, start the included mock receiver:
```bash
node test/receiver.js
```
The receiver listens on `http://localhost:4000/webhook` and logs all incoming headers, payloads, and HMAC verification results.

---

## API Reference

### POST `/events`
Accepts and queues an event for delivery.

**Request Body:**
```json
{
  "type": "payment.failed",
  "payload": {
    "account_id": "acc_001",
    "amount": 49.99,
    "currency": "USD"
  },
  "webhook_url": "https://webhook.site/your-unique-id"
}
```

**Response (`201 Created`):**
```json
{
  "id": "e9b5e5d3-82a9-4670-8bf1-bdaff52d7e48",
  "type": "payment.failed",
  "payload": {
    "account_id": "acc_001",
    "amount": 49.99,
    "currency": "USD"
  },
  "webhook_url": "https://webhook.site/your-unique-id",
  "status": "pending",
  "created_at": "2026-10-25T18:15:30.123Z",
  "attempts": []
}
```

---

### GET `/events`
Retrieves a list of all events with their delivery statuses and attempt histories.

**Response (`200 OK`):**
```json
[
  {
    "id": "e9b5e5d3-82a9-4670-8bf1-bdaff52d7e48",
    "type": "payment.failed",
    "payload": { "account_id": "acc_001", "amount": 49.99, "currency": "USD" },
    "webhook_url": "https://webhook.site/your-unique-id",
    "status": "delivered",
    "created_at": "2026-10-25T18:15:30.123Z",
    "attempts": [
      {
        "attempted_at": "2026-10-25T18:15:30.145Z",
        "http_status": 200,
        "outcome": "success"
      }
    ]
  }
]
```

---

### GET `/events/:id`
Retrieves a single event by ID with its complete attempt history.

**Response (`200 OK`):**
```json
{
  "id": "e9b5e5d3-82a9-4670-8bf1-bdaff52d7e48",
  "type": "payment.failed",
  "payload": { "account_id": "acc_001", "amount": 49.99, "currency": "USD" },
  "webhook_url": "https://webhook.site/your-unique-id",
  "status": "dead",
  "created_at": "2026-10-25T18:15:30.123Z",
  "attempts": [
    {
      "attempted_at": "2026-10-25T18:15:30.145Z",
      "http_status": 500,
      "outcome": "failed"
    },
    {
      "attempted_at": "2026-10-25T18:16:00.150Z",
      "http_status": 500,
      "outcome": "failed"
    },
    {
      "attempted_at": "2026-10-25T18:21:00.160Z",
      "http_status": null,
      "outcome": "failed"
    },
    {
      "attempted_at": "2026-10-25T18:51:00.170Z",
      "http_status": 503,
      "outcome": "failed"
    }
  ]
}
```

---

### POST `/events/:id/retry`
Manually triggers a retry for an event that has reached `dead` status.

**Validation Rules:**
- Returns `200 OK` with the re-queued event (`status: "pending"`) if the event is currently `dead`.
- Returns `400 Bad Request` if the event is not in `dead` status.
- Returns `404 Not Found` if the event ID does not exist.

**Response (`200 OK`):**
```json
{
  "id": "e9b5e5d3-82a9-4670-8bf1-bdaff52d7e48",
  "type": "payment.failed",
  "payload": { "account_id": "acc_001", "amount": 49.99, "currency": "USD" },
  "webhook_url": "https://webhook.site/your-unique-id",
  "status": "pending",
  "created_at": "2026-10-25T18:15:30.123Z",
  "attempts": [ ... ]
}
```

---

## Retry Scheduling Approach

### No External Queues Constraint
As required by the specification, no queue library (such as BullMQ, Celery, or RQ) is used. The retry scheduling mechanism is completely self-implemented:

1. **Scheduling via Persistent Timestamps**:
   - Each event row in the SQLite database stores a `status`, `retry_count`, and `next_retry_at` (ISO timestamp).
   - Upon initial ingestion, `next_retry_at` is set to the current time (`now`), allowing immediate delivery.
2. **Autonomous Background Worker**:
   - The worker runs an independent loop polling the database for due events:
     ```sql
     SELECT * FROM events
     WHERE status IN ('pending', 'failed')
       AND (next_retry_at IS NULL OR next_retry_at <= datetime('now'))
     ORDER BY next_retry_at ASC
     LIMIT 20;
     ```
   - In-memory event locks (`inFlight` set) and forward timestamp leases prevent duplicate deliveries when multiple ticks run.
3. **Delivery Rules & Schedule Transitions**:
   - **Initial Attempt**: Executed immediately upon ingestion.
   - **Retry 1**: If attempt 1 fails &rarr; status becomes `failed`, scheduled after **30 seconds** (`+30,000 ms`).
   - **Retry 2**: If attempt 2 fails &rarr; status becomes `failed`, scheduled after **5 minutes** (`+300,000 ms`).
   - **Retry 3**: If attempt 3 fails &rarr; status becomes `failed`, scheduled after **30 minutes** (`+1,800,000 ms`).
   - **Dead Status**: If attempt 4 (the 3rd retry) fails &rarr; status transitions to `dead`, `next_retry_at` is cleared to `null`, and automatic retries cease.
   - **Success**: A `2xx` response at any attempt transitions status to `delivered` immediately and stops further attempts.

---

## HMAC-SHA256 Signing & Verification

Every outgoing HTTP POST request is signed with an HMAC-SHA256 signature passed in the `X-Webhook-Signature` header.

### Outgoing Headers:
- `Content-Type: application/json`
- `X-Webhook-Signature: <hex-digest>`
- `X-Webhook-Event: <event-type>`
- `X-Webhook-Id: <event-id>`

### Outgoing Payload Structure:
The outgoing request body is a JSON object with:
```json
{
  "id": "e9b5e5d3-82a9-4670-8bf1-bdaff52d7e48",
  "type": "payment.failed",
  "payload": { ... },
  "created_at": "2026-10-25T18:15:30.123Z"
}
```

### Signature Computation:
$$\text{Signature} = \text{HMAC-SHA256}_{\text{SECRET}}(\text{rawRequestBody})$$

### Verification Example (Node.js)
```javascript
import crypto from 'node:crypto';

function verifyWebhook(rawBody, signatureHeader, secret) {
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(rawBody, 'utf8')
    .digest('hex');

  const expectedBuf = Buffer.from(expectedSignature, 'hex');
  const receivedBuf = Buffer.from(signatureHeader, 'hex');

  if (expectedBuf.length !== receivedBuf.length) {
    return false;
  }

  // Constant-time comparison to prevent timing attacks
  return crypto.timingSafeEqual(expectedBuf, receivedBuf);
}
```

### Verification Example (Python)
```python
import hmac
import hashlib

def verify_webhook(raw_body_bytes: bytes, signature_header: str, secret: str) -> bool:
    expected = hmac.new(
        secret.encode('utf-8'),
        raw_body_bytes,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature_header)
```

---

## Server Restart Behavior & In-Progress Retries

### How Server Restarts Affect Retries
In many in-memory architectures (e.g. `setTimeout` or in-memory queues), restarting the application drops all pending timers, losing in-progress retries permanently.

### How Our Implementation Handles It
Our implementation uses **SQLite database persistence** (`data/webhooks.db`) with Write-Ahead Logging (`WAL` mode). 

Here is what happens during a server restart:
1. **Preserved State**: All events, their current statuses (`pending`, `failed`, `dead`), retry counters, and scheduled `next_retry_at` timestamps are committed to disk.
2. **Automatic Resumption on Boot**:
   - When the server and delivery worker restart, the worker immediately queries the database for events where `status IN ('pending', 'failed') AND next_retry_at <= datetime('now')`.
   - **Retries that became due while the server was down** are picked up and executed immediately.
   - **Retries scheduled for the future** (e.g., 5 or 30 minutes later) will fire exactly when their scheduled `next_retry_at` arrives.
3. **No Duplicate or Lost Deliveries**:
   - In-flight lease timestamps ensure that an unacknowledged attempt from a sudden hard kill does not leave the event stranded, as the lease expires and allows the retry scheduler to re-evaluate it.

---

## Deployment & Submission Notes

### Evaluator Contributors
The following contributors should be added to your private submission repository:
- `bishal@nestack.com`
- `sannidhya@nestack.com`
- `sanjay@nestack.com`

### Live Deployment Link
- **Deployment URL**: `https://webhook-delivery-engine.example.com` *(Replace with your live hosted URL, e.g., Render / Fly.io / Railway / AWS / DigitalOcean)*
- **Health Check**: `GET /health` returns `200 OK` (`{"status":"ok"}`).
- **Authentication**: Single hardcoded customer; no customer authentication headers required.
