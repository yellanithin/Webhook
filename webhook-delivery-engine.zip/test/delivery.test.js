import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { initDatabase } from '../src/db/database.js';
import { EventRepository } from '../src/db/repository.js';
import { DeliveryEngine } from '../src/services/deliveryEngine.js';
import { verifySignature } from '../src/services/signature.js';

test('Delivery Engine Suite', async (t) => {
  const secret = 'whsec_delivery_test_secret_777';

  // Helper to create a mock webhook receiver server
  function createMockReceiver(handler) {
    return new Promise((resolve) => {
      const server = http.createServer((req, res) => {
        let body = '';
        req.on('data', chunk => { body += chunk; });
        req.on('end', () => {
          handler(req, res, body);
        });
      });
      server.listen(0, () => {
        const port = server.address().port;
        resolve({
          server,
          url: `http://127.0.0.1:${port}/webhook`,
          close: () => new Promise(cb => server.close(cb))
        });
      });
    });
  }

  await t.test('delivers immediately on ingestion and marks status delivered for 2xx response', async () => {
    const db = initDatabase(':memory:');
    const repository = new EventRepository(db);

    let receivedHeaders = null;
    let receivedBody = null;

    const receiver = await createMockReceiver((req, res, body) => {
      receivedHeaders = req.headers;
      receivedBody = body;
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ received: true }));
    });

    const engine = new DeliveryEngine({
      repository,
      secret,
      retryScheduleMs: [100, 200, 300],
      requestTimeoutMs: 2000,
      pollIntervalMs: 50
    });
    engine.start();

    try {
      const event = repository.createEvent({
        type: 'payment.success',
        payload: { amount: 500, currency: 'USD' },
        webhook_url: receiver.url
      });
      engine.wakeUp();

      // Wait briefly for delivery
      let deliveredEvent = null;
      for (let i = 0; i < 30; i++) {
        await new Promise(r => setTimeout(r, 50));
        deliveredEvent = repository.getEventById(event.id);
        if (deliveredEvent.status === 'delivered') break;
      }

      assert.strictEqual(deliveredEvent.status, 'delivered');
      assert.strictEqual(deliveredEvent.attempts.length, 1);
      assert.strictEqual(deliveredEvent.attempts[0].outcome, 'success');
      assert.strictEqual(deliveredEvent.attempts[0].http_status, 200);
      assert.ok(deliveredEvent.attempts[0].attempted_at);

      // Verify HMAC-SHA256 signature was present and valid
      assert.ok(receivedHeaders['x-webhook-signature'], 'X-Webhook-Signature must be present');
      assert.strictEqual(receivedHeaders['x-webhook-event'], 'payment.success');
      const isSignatureValid = verifySignature(receivedBody, receivedHeaders['x-webhook-signature'], secret);
      assert.strictEqual(isSignatureValid, true, 'Signature must be verifiable with shared secret');

      const parsed = JSON.parse(receivedBody);
      assert.strictEqual(parsed.id, event.id);
      assert.strictEqual(parsed.type, 'payment.success');
      assert.deepStrictEqual(parsed.payload, { amount: 500, currency: 'USD' });
    } finally {
      await engine.stop();
      await receiver.close();
    }
  });

  await t.test('retries on non-2xx status and transitions to dead after 3 failed retries (4 total attempts)', async () => {
    const db = initDatabase(':memory:');
    const repository = new EventRepository(db);

    let attemptsCount = 0;
    const receiver = await createMockReceiver((req, res) => {
      attemptsCount++;
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Server error' }));
    });

    // Custom rapid retry schedule for testing: 60ms, 120ms, 180ms
    const engine = new DeliveryEngine({
      repository,
      secret,
      retryScheduleMs: [60, 120, 180],
      requestTimeoutMs: 1000,
      pollIntervalMs: 20
    });
    engine.start();

    try {
      const event = repository.createEvent({
        type: 'invoice.failed',
        payload: { invoice_id: 'inv_99' },
        webhook_url: receiver.url
      });
      engine.wakeUp();

      // Wait until event reaches dead status
      let finalEvent = null;
      for (let i = 0; i < 60; i++) {
        await new Promise(r => setTimeout(r, 50));
        finalEvent = repository.getEventById(event.id);
        if (finalEvent.status === 'dead') break;
      }

      assert.strictEqual(finalEvent.status, 'dead');
      // 1 initial attempt + 3 retries = 4 total attempts
      assert.strictEqual(finalEvent.attempts.length, 4);
      assert.strictEqual(attemptsCount, 4);

      for (const attempt of finalEvent.attempts) {
        assert.strictEqual(attempt.outcome, 'failed');
        assert.strictEqual(attempt.http_status, 500);
        assert.ok(attempt.attempted_at);
      }
    } finally {
      await engine.stop();
      await receiver.close();
    }
  });

  await t.test('handles request timeouts as failure with http_status null', async () => {
    const db = initDatabase(':memory:');
    const repository = new EventRepository(db);

    // Receiver that deliberately delays beyond timeout
    const receiver = await createMockReceiver((req, res) => {
      setTimeout(() => {
        try {
          res.writeHead(200);
          res.end('ok');
        } catch {}
      }, 500);
    });

    const engine = new DeliveryEngine({
      repository,
      secret,
      retryScheduleMs: [5000, 10000, 20000],
      requestTimeoutMs: 100, // Abort after 100ms
      pollIntervalMs: 30
    });
    engine.start();

    try {
      const event = repository.createEvent({
        type: 'timeout.test',
        payload: { test: true },
        webhook_url: receiver.url
      });
      engine.wakeUp();

      let eventWithAttempt = null;
      for (let i = 0; i < 30; i++) {
        await new Promise(r => setTimeout(r, 50));
        eventWithAttempt = repository.getEventById(event.id);
        if (eventWithAttempt.attempts.length > 0) break;
      }

      assert.strictEqual(eventWithAttempt.status, 'failed');
      assert.strictEqual(eventWithAttempt.attempts.length, 1);
      assert.strictEqual(eventWithAttempt.attempts[0].outcome, 'failed');
      assert.strictEqual(eventWithAttempt.attempts[0].http_status, null);
    } finally {
      await engine.stop();
      await receiver.close();
    }
  });

  await t.test('handles network errors (connection refused) without crashing', async () => {
    const db = initDatabase(':memory:');
    const repository = new EventRepository(db);

    // Use a port where nothing is listening
    const invalidUrl = 'http://127.0.0.1:59999/webhook';

    const engine = new DeliveryEngine({
      repository,
      secret,
      retryScheduleMs: [5000, 10000, 20000],
      requestTimeoutMs: 500,
      pollIntervalMs: 30
    });
    engine.start();

    try {
      const event = repository.createEvent({
        type: 'network.error.test',
        payload: { test: true },
        webhook_url: invalidUrl
      });
      engine.wakeUp();

      let eventWithAttempt = null;
      for (let i = 0; i < 30; i++) {
        await new Promise(r => setTimeout(r, 50));
        eventWithAttempt = repository.getEventById(event.id);
        if (eventWithAttempt.attempts.length > 0) break;
      }

      assert.strictEqual(eventWithAttempt.status, 'failed');
      assert.strictEqual(eventWithAttempt.attempts.length, 1);
      assert.strictEqual(eventWithAttempt.attempts[0].outcome, 'failed');
      assert.strictEqual(eventWithAttempt.attempts[0].http_status, null);
    } finally {
      await engine.stop();
    }
  });

  await t.test('allows re-queuing a dead event and successfully delivering upon manual retry', async () => {
    const db = initDatabase(':memory:');
    const repository = new EventRepository(db);

    let returnSuccess = false;
    const receiver = await createMockReceiver((req, res) => {
      if (returnSuccess) {
        res.writeHead(200);
        res.end('recovered');
      } else {
        res.writeHead(503);
        res.end('service unavailable');
      }
    });

    const engine = new DeliveryEngine({
      repository,
      secret,
      retryScheduleMs: [40, 80, 120],
      requestTimeoutMs: 1000,
      pollIntervalMs: 20
    });
    engine.start();

    try {
      const event = repository.createEvent({
        type: 'service.down',
        payload: { item: 'sample' },
        webhook_url: receiver.url
      });
      engine.wakeUp();

      // Wait until event dies
      let deadEvent = null;
      for (let i = 0; i < 50; i++) {
        await new Promise(r => setTimeout(r, 40));
        deadEvent = repository.getEventById(event.id);
        if (deadEvent.status === 'dead') break;
      }

      assert.strictEqual(deadEvent.status, 'dead');
      assert.strictEqual(deadEvent.attempts.length, 4);

      // Now endpoint recovers!
      returnSuccess = true;

      // Re-queue the dead event
      const requeueResult = repository.requeueDeadEvent(deadEvent.id);
      assert.strictEqual(requeueResult.success, true);
      assert.strictEqual(requeueResult.event.status, 'pending');

      engine.wakeUp();

      // Wait for delivery to succeed
      let recoveredEvent = null;
      for (let i = 0; i < 40; i++) {
        await new Promise(r => setTimeout(r, 40));
        recoveredEvent = repository.getEventById(deadEvent.id);
        if (recoveredEvent.status === 'delivered') break;
      }

      assert.strictEqual(recoveredEvent.status, 'delivered');
      // Total attempts = 4 previous failures + 1 recovery success = 5 attempts
      assert.strictEqual(recoveredEvent.attempts.length, 5);
      assert.strictEqual(recoveredEvent.attempts[4].outcome, 'success');
      assert.strictEqual(recoveredEvent.attempts[4].http_status, 200);
    } finally {
      await engine.stop();
      await receiver.close();
    }
  });
});
