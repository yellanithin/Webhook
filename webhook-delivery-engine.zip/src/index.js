import { config } from './config.js';
import { initDatabase } from './db/database.js';
import { EventRepository } from './db/repository.js';
import { DeliveryEngine } from './services/deliveryEngine.js';
import { createApp } from './app.js';
import { logger } from './utils/logger.js';

const db = initDatabase(config.databasePath);
const repository = new EventRepository(db);

const deliveryEngine = new DeliveryEngine({
  repository,
  secret: config.webhookSecret,
  retryScheduleMs: config.retryScheduleMs,
  requestTimeoutMs: config.requestTimeoutMs,
  pollIntervalMs: config.workerPollIntervalMs
});

// Start background worker alongside the server
deliveryEngine.start();

// Create and start API server
const app = createApp({ repository, deliveryEngine });

const server = app.listen(config.port, () => {
  logger.info(`Webhook Delivery Engine running (Server + Background Worker)`);
  logger.info(`API Server: http://localhost:${config.port}`);
  logger.info(`Database: ${config.databasePath}`);
  logger.info(`Retry Schedule: ${config.retryScheduleMs.map(ms => ms / 1000 + 's').join(' -> ')}`);
});

async function gracefulShutdown(signal) {
  logger.info(`Received ${signal}. Gracefully stopping server and worker...`);
  server.close(async () => {
    await deliveryEngine.stop();
    logger.info('Engine shutdown complete');
    process.exit(0);
  });
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
