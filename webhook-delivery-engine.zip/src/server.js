import { config } from './config.js';
import { initDatabase } from './db/database.js';
import { EventRepository } from './db/repository.js';
import { createApp } from './app.js';
import { logger } from './utils/logger.js';

const db = initDatabase(config.databasePath);
const repository = new EventRepository(db);

const app = createApp({ repository });

const server = app.listen(config.port, () => {
  logger.info(`Webhook API server listening on port ${config.port}`);
  logger.info(`Database located at ${config.databasePath}`);
});

function gracefulShutdown(signal) {
  logger.info(`Received ${signal}. Shutting down API server...`);
  server.close(() => {
    logger.info('API server closed');
    process.exit(0);
  });
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
