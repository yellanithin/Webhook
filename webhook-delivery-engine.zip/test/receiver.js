import http from 'node:http';
import { verifySignature } from '../src/services/signature.js';

const PORT = parseInt(process.env.RECEIVER_PORT || '4000', 10);
const SECRET = process.env.WEBHOOK_SECRET || 'whsec_nestack_super_secret_key_2026';

const server = http.createServer((req, res) => {
  let rawBody = '';

  req.on('data', chunk => {
    rawBody += chunk;
  });

  req.on('end', () => {
    const signature = req.headers['x-webhook-signature'];
    const eventType = req.headers['x-webhook-event'];
    const eventId = req.headers['x-webhook-id'];

    const isValid = verifySignature(rawBody, signature, SECRET);

    console.log(`\n--- [Webhook Received at ${new Date().toISOString()}] ---`);
    console.log(`URL: ${req.url}`);
    console.log(`Event ID: ${eventId}`);
    console.log(`Event Type: ${eventType}`);
    console.log(`Signature: ${signature}`);
    console.log(`Signature Valid?: ${isValid ? 'VALID' : 'INVALID'}`);

    let parsedBody;
    try {
      parsedBody = JSON.parse(rawBody);
      console.log('Payload:', JSON.stringify(parsedBody, null, 2));
    } catch {
      console.log('Raw Body:', rawBody);
    }

    // Support behavior modes via query parameters
    const urlObj = new URL(req.url, `http://localhost:${PORT}`);
    const mode = urlObj.searchParams.get('mode') || 'success';

    if (mode === 'fail') {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'error', message: 'Simulated 500 internal server error' }));
    } else if (mode === 'timeout') {
      console.log('Simulating slow response (hanging connection)...');
      setTimeout(() => {
        try {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ status: 'ok_after_delay' }));
        } catch {}
      }, 15000);
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'success', verified: isValid }));
    }
  });
});

server.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`Mock Webhook Receiver listening on http://localhost:${PORT}`);
  console.log(`Verifying signatures with secret: "${SECRET}"`);
  console.log(`Modes supported:`);
  console.log(`  http://localhost:${PORT}/webhook (200 OK)`);
  console.log(`  http://localhost:${PORT}/webhook?mode=fail (500 Error)`);
  console.log(`  http://localhost:${PORT}/webhook?mode=timeout (Slow Timeout)`);
  console.log(`====================================================`);
});
