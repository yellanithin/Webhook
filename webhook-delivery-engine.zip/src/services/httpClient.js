import { generateSignature } from './signature.js';

/**
 * Dispatches a webhook delivery HTTP request to the customer endpoint.
 *
 * @param {Object} event - Event object containing id, type, payload, created_at, webhook_url.
 * @param {string} secret - Secret key for HMAC-SHA256 signature.
 * @param {number} timeoutMs - Timeout limit in milliseconds.
 * @returns {Promise<{ outcome: 'success' | 'failed', httpStatus: number | null, errorMessage: string | null, responseTimeMs: number }>}
 */
export async function sendWebhookRequest(event, secret, timeoutMs = 5000) {
  const webhookBody = {
    id: event.id,
    type: event.type,
    payload: typeof event.payload === 'string' ? JSON.parse(event.payload) : event.payload,
    created_at: event.created_at
  };

  const rawBody = JSON.stringify(webhookBody);
  const signature = generateSignature(rawBody, secret);

  const startTime = Date.now();
  let controller = null;
  let timeoutId = null;

  try {
    const signal = AbortSignal.timeout(timeoutMs);

    const response = await fetch(event.webhook_url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Nestack-Webhook-Delivery-Engine/1.0',
        'X-Webhook-Signature': signature,
        'X-Webhook-Event': event.type,
        'X-Webhook-Id': event.id
      },
      body: rawBody,
      signal
    });

    const responseTimeMs = Date.now() - startTime;
    const isSuccess = response.status >= 200 && response.status < 300;

    return {
      outcome: isSuccess ? 'success' : 'failed',
      httpStatus: response.status,
      errorMessage: isSuccess ? null : `Target returned non-2xx status code: ${response.status} ${response.statusText}`,
      responseTimeMs
    };
  } catch (err) {
    const responseTimeMs = Date.now() - startTime;
    const isTimeout = err.name === 'TimeoutError' || (err.cause && err.cause.name === 'TimeoutError');

    return {
      outcome: 'failed',
      httpStatus: null,
      errorMessage: isTimeout ? `Request timed out after ${timeoutMs}ms` : (err.message || 'Network error'),
      responseTimeMs
    };
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}
