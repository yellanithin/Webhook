import test from 'node:test';
import assert from 'node:assert/strict';
import { initDatabase } from '../src/db/database.js';
import { EventRepository } from '../src/db/repository.js';
import { createApp } from '../src/app.js';

test('Events API Endpoints Suite', async (t) => {
  const db = initDatabase(':memory:');
  const repository = new EventRepository(db);
  const app = createApp({ repository });

  // Start temporary test server
  const server = await new Promise(resolve => {
    const s = app.listen(0, () => resolve(s));
  });
  const baseUrl = `http://127.0.0.1:${server.address().port}`;

  t.after(() => {
    server.close();
  });

  let createdEventId;

  await t.test('POST /events creates an event with status "pending"', async () => {
    const res = await fetch(`${baseUrl}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'user.signup',
        payload: { user_id: 'usr_123', email: 'alice@example.com' },
        webhook_url: 'https://example.com/webhook-endpoint'
      })
    });

    assert.strictEqual(res.status, 201);
    const body = await res.json();

    assert.ok(body.id, 'Expected id to be present');
    assert.strictEqual(body.type, 'user.signup');
    assert.deepStrictEqual(body.payload, { user_id: 'usr_123', email: 'alice@example.com' });
    assert.strictEqual(body.webhook_url, 'https://example.com/webhook-endpoint');
    assert.strictEqual(body.status, 'pending');
    assert.ok(body.created_at, 'Expected created_at to be present');
    assert.deepStrictEqual(body.attempts, []);

    createdEventId = body.id;
  });

  await t.test('POST /events validates missing type', async () => {
    const res = await fetch(`${baseUrl}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        payload: { foo: 'bar' },
        webhook_url: 'https://example.com/webhook'
      })
    });

    assert.strictEqual(res.status, 400);
    const body = await res.json();
    assert.match(body.error, /type/i);
  });

  await t.test('POST /events validates missing payload', async () => {
    const res = await fetch(`${baseUrl}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'order.placed',
        webhook_url: 'https://example.com/webhook'
      })
    });

    assert.strictEqual(res.status, 400);
    const body = await res.json();
    assert.match(body.error, /payload/i);
  });

  await t.test('POST /events validates invalid webhook_url', async () => {
    const res = await fetch(`${baseUrl}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'order.placed',
        payload: { id: 1 },
        webhook_url: 'invalid-url'
      })
    });

    assert.strictEqual(res.status, 400);
    const body = await res.json();
    assert.match(body.error, /webhook_url/i);
  });

  await t.test('GET /events returns an array of event objects', async () => {
    const res = await fetch(`${baseUrl}/events`);
    assert.strictEqual(res.status, 200);

    const body = await res.json();
    assert.ok(Array.isArray(body), 'Expected array response');
    assert.strictEqual(body.length, 1);
    assert.strictEqual(body[0].id, createdEventId);
    assert.strictEqual(body[0].status, 'pending');
    assert.ok(Array.isArray(body[0].attempts));
  });

  await t.test('GET /events/:id returns single event with attempt history', async () => {
    const res = await fetch(`${baseUrl}/events/${createdEventId}`);
    assert.strictEqual(res.status, 200);

    const body = await res.json();
    assert.strictEqual(body.id, createdEventId);
    assert.strictEqual(body.type, 'user.signup');
    assert.strictEqual(body.status, 'pending');
    assert.deepStrictEqual(body.attempts, []);
  });

  await t.test('GET /events/:id returns 404 for unknown id', async () => {
    const res = await fetch(`${baseUrl}/events/unknown-id-12345`);
    assert.strictEqual(res.status, 404);
    const body = await res.json();
    assert.match(body.error, /not found/i);
  });

  await t.test('POST /events/:id/retry returns 400 if event status is NOT dead', async () => {
    // Current status is 'pending'
    const res = await fetch(`${baseUrl}/events/${createdEventId}/retry`, {
      method: 'POST'
    });

    assert.strictEqual(res.status, 400);
    const body = await res.json();
    assert.match(body.error, /only dead events/i);
  });

  await t.test('POST /events/:id/retry returns 404 for unknown event id', async () => {
    const res = await fetch(`${baseUrl}/events/unknown-id-12345/retry`, {
      method: 'POST'
    });

    assert.strictEqual(res.status, 404);
    const body = await res.json();
    assert.match(body.error, /not found/i);
  });

  await t.test('POST /events/:id/retry re-queues event when dead', async () => {
    // Simulate event becoming dead
    repository.updateEventStatus(createdEventId, {
      status: 'dead',
      retryCount: 4,
      nextRetryAt: null
    });

    // Verify it is now dead
    const checkDead = repository.getEventById(createdEventId);
    assert.strictEqual(checkDead.status, 'dead');

    // Call retry endpoint
    const res = await fetch(`${baseUrl}/events/${createdEventId}/retry`, {
      method: 'POST'
    });

    assert.strictEqual(res.status, 200);
    const body = await res.json();
    assert.strictEqual(body.id, createdEventId);
    assert.strictEqual(body.status, 'pending');

    // Verify database reflects pending status
    const refreshed = repository.getEventById(createdEventId);
    assert.strictEqual(refreshed.status, 'pending');
  });
});
