import { config } from './config.js';
import { initDatabase } from './db/database.js';
import { EventRepository } from './db/repository.js';
import { DeliveryEngine } from './services/deliveryEngine.js';
import { logger } from './utils/logger.js';

const db = initDatabase(config.databasePath);
const repository = new EventRepository(db);

const deliveryEngine = new DeliveryEngine({
  repository,
  secret: config.webhookSecret,
  retryScheduleMs: config.retryScheduleMs,
  requestTimeoutMs: config.requestTimeoutMs,
  pollIntervalMs: config.workerPollIntervalMs
});

deliveryEngine.start();
logger.info('Standalone background delivery worker is running...');

async function gracefulShutdown(signal) {
  logger.info(`Received ${signal}. Stopping delivery worker...`);
  await deliveryEngine.stop();
  logger.info('Delivery worker stopped');
  process.exit(0);
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
