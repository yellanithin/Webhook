import test from 'node:test';
import assert from 'node:assert/strict';
import { generateSignature, verifySignature } from '../src/services/signature.js';

test('HMAC-SHA256 Signing Suite', async (t) => {
  const secret = 'test-secret-key-12345';
  const payload = JSON.stringify({ event: 'payment.failed', amount: 99.99 });

  await t.test('generates deterministic hex signature for identical input', () => {
    const sig1 = generateSignature(payload, secret);
    const sig2 = generateSignature(payload, secret);
    assert.strictEqual(sig1, sig2);
    assert.match(sig1, /^[a-f0-9]{64}$/); // 64 hex characters for SHA-256
  });

  await t.test('generates different signature if payload changes', () => {
    const sig1 = generateSignature(payload, secret);
    const sig2 = generateSignature(JSON.stringify({ event: 'payment.failed', amount: 100.00 }), secret);
    assert.notStrictEqual(sig1, sig2);
  });

  await t.test('generates different signature if secret changes', () => {
    const sig1 = generateSignature(payload, secret);
    const sig2 = generateSignature(payload, 'different-secret');
    assert.notStrictEqual(sig1, sig2);
  });

  await t.test('verifySignature returns true for valid signature', () => {
    const signature = generateSignature(payload, secret);
    const isValid = verifySignature(payload, signature, secret);
    assert.strictEqual(isValid, true);
  });

  await t.test('verifySignature returns false for tampered payload', () => {
    const signature = generateSignature(payload, secret);
    const tamperedPayload = JSON.stringify({ event: 'payment.failed', amount: 0.01 });
    const isValid = verifySignature(tamperedPayload, signature, secret);
    assert.strictEqual(isValid, false);
  });

  await t.test('verifySignature returns false for incorrect secret', () => {
    const signature = generateSignature(payload, secret);
    const isValid = verifySignature(payload, signature, 'wrong-secret');
    assert.strictEqual(isValid, false);
  });

  await t.test('verifySignature returns false for malformed or missing signature', () => {
    assert.strictEqual(verifySignature(payload, '', secret), false);
    assert.strictEqual(verifySignature(payload, null, secret), false);
    assert.strictEqual(verifySignature(payload, 'not-a-valid-hex-string', secret), false);
  });
});
