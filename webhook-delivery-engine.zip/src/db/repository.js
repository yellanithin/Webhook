import crypto from 'node:crypto';

export class EventRepository {
  /**
   * @param {import('node:sqlite').DatabaseSync} db
   */
  constructor(db) {
    this.db = db;

    // Prepared statements for high performance
    this.stmtInsertEvent = this.db.prepare(`
      INSERT INTO events (id, type, payload, webhook_url, status, retry_count, next_retry_at, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    this.stmtGetEventById = this.db.prepare(`
      SELECT id, type, payload, webhook_url, status, retry_count, next_retry_at, created_at, updated_at
      FROM events
      WHERE id = ?
    `);

    this.stmtListEvents = this.db.prepare(`
      SELECT id, type, payload, webhook_url, status, retry_count, next_retry_at, created_at, updated_at
      FROM events
      ORDER BY created_at DESC
    `);

    this.stmtGetAttemptsByEventId = this.db.prepare(`
      SELECT id, attempt_number, attempted_at, http_status, outcome, error_message, response_time_ms
      FROM attempts
      WHERE event_id = ?
      ORDER BY attempted_at ASC, rowid ASC
    `);

    this.stmtGetAllAttempts = this.db.prepare(`
      SELECT event_id, attempt_number, attempted_at, http_status, outcome, error_message, response_time_ms
      FROM attempts
      ORDER BY attempted_at ASC, rowid ASC
    `);

    this.stmtGetAttemptCountByEventId = this.db.prepare(`
      SELECT COUNT(*) as count
      FROM attempts
      WHERE event_id = ?
    `);

    this.stmtInsertAttempt = this.db.prepare(`
      INSERT INTO attempts (id, event_id, attempt_number, attempted_at, http_status, outcome, error_message, response_time_ms)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    this.stmtUpdateEventStatus = this.db.prepare(`
      UPDATE events
      SET status = ?, retry_count = ?, next_retry_at = ?, updated_at = ?
      WHERE id = ?
    `);

    this.stmtRequeueEvent = this.db.prepare(`
      UPDATE events
      SET status = 'pending', retry_count = 0, next_retry_at = ?, updated_at = ?
      WHERE id = ? AND status = 'dead'
    `);

    this.stmtGetDueEvents = this.db.prepare(`
      SELECT id, type, payload, webhook_url, status, retry_count, next_retry_at, created_at, updated_at
      FROM events
      WHERE status IN ('pending', 'failed')
        AND (next_retry_at IS NULL OR next_retry_at <= ?)
      ORDER BY next_retry_at ASC, created_at ASC
      LIMIT ?
    `);
  }

  /**
   * Creates and stores a new event.
   *
   * @param {Object} data
   * @param {string} data.type
   * @param {any} data.payload
   * @param {string} data.webhook_url
   * @returns {Object} Created event object with empty attempts array.
   */
  createEvent({ type, payload, webhook_url }) {
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const payloadStr = typeof payload === 'string' ? payload : JSON.stringify(payload);
    const status = 'pending';
    const retryCount = 0;
    const nextRetryAt = now; // Ready immediately

    this.stmtInsertEvent.run(
      id,
      type,
      payloadStr,
      webhook_url,
      status,
      retryCount,
      nextRetryAt,
      now,
      now
    );

    return {
      id,
      type,
      payload: typeof payload === 'string' ? JSON.parse(payload) : payload,
      webhook_url,
      status,
      created_at: now,
      attempts: []
    };
  }

  /**
   * Retrieves an event by its ID including its attempts history.
   *
   * @param {string} id
   * @returns {Object | null} Event object with attempts, or null if not found.
   */
  getEventById(id) {
    const row = this.stmtGetEventById.get(id);
    if (!row) {
      return null;
    }

    const attemptsRows = this.stmtGetAttemptsByEventId.all(id);
    return this._formatEvent(row, attemptsRows);
  }

  /**
   * Retrieves all events with their attempts histories.
   *
   * @returns {Array<Object>} List of event objects.
   */
  listEvents() {
    const eventRows = this.stmtListEvents.all();
    if (eventRows.length === 0) {
      return [];
    }

    const allAttempts = this.stmtGetAllAttempts.all();
    const attemptsByEventId = new Map();

    for (const att of allAttempts) {
      if (!attemptsByEventId.has(att.event_id)) {
        attemptsByEventId.set(att.event_id, []);
      }
      attemptsByEventId.get(att.event_id).push(att);
    }

    return eventRows.map(row =>
      this._formatEvent(row, attemptsByEventId.get(row.id) || [])
    );
  }

  /**
   * Re-queues a dead event for immediate redelivery.
   *
   * @param {string} id
   * @returns {{ success: boolean, event?: Object, error?: string }}
   */
  requeueDeadEvent(id) {
    const event = this.getEventById(id);
    if (!event) {
      return { success: false, error: 'not_found' };
    }

    if (event.status !== 'dead') {
      return { success: false, error: 'not_dead' };
    }

    const now = new Date().toISOString();
    const result = this.stmtRequeueEvent.run(now, now, id);

    if (result.changes === 0) {
      return { success: false, error: 'not_dead' };
    }

    const updated = this.getEventById(id);
    return { success: true, event: updated };
  }

  /**
   * Gets events due for delivery attempt.
   *
   * @param {number} limit
   * @returns {Array<Object>}
   */
  getDueEvents(limit = 10) {
    const now = new Date().toISOString();
    return this.stmtGetDueEvents.all(now, limit);
  }

  /**
   * Records a delivery attempt for an event.
   *
   * @param {Object} attempt
   */
  recordAttempt({ eventId, attemptedAt, httpStatus, outcome, errorMessage, responseTimeMs }) {
    const countRow = this.stmtGetAttemptCountByEventId.get(eventId);
    const attemptNumber = (countRow ? Number(countRow.count) : 0) + 1;
    const id = crypto.randomUUID();

    this.stmtInsertAttempt.run(
      id,
      eventId,
      attemptNumber,
      attemptedAt,
      httpStatus !== undefined ? httpStatus : null,
      outcome,
      errorMessage || null,
      responseTimeMs !== undefined ? responseTimeMs : null
    );

    return attemptNumber;
  }

  /**
   * Updates status and retry metadata of an event.
   *
   * @param {string} eventId
   * @param {Object} update
   */
  updateEventStatus(eventId, { status, retryCount, nextRetryAt }) {
    const now = new Date().toISOString();
    this.stmtUpdateEventStatus.run(
      status,
      retryCount,
      nextRetryAt !== undefined ? nextRetryAt : null,
      now,
      eventId
    );
  }

  /**
   * Formats an event row into the public API response schema.
   * @private
   */
  _formatEvent(row, attempts) {
    let parsedPayload;
    try {
      parsedPayload = JSON.parse(row.payload);
    } catch {
      parsedPayload = row.payload;
    }

    return {
      id: row.id,
      type: row.type,
      payload: parsedPayload,
      webhook_url: row.webhook_url,
      status: row.status,
      created_at: row.created_at,
      attempts: attempts.map(a => ({
        attempted_at: a.attempted_at,
        http_status: a.http_status !== undefined ? a.http_status : null,
        outcome: a.outcome
      }))
    };
  }
}
