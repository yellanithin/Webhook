import crypto from 'node:crypto';

/**
 * Generates an HMAC-SHA256 signature for a webhook payload string.
 *
 * @param {string} payloadString - The raw stringified JSON body of the outgoing webhook request.
 * @param {string} secret - The shared HMAC secret key.
 * @returns {string} The hex-encoded HMAC-SHA256 digest.
 */
export function generateSignature(payloadString, secret) {
  if (!secret) {
    throw new Error('HMAC signing secret must be provided');
  }
  return crypto
    .createHmac('sha256', secret)
    .update(payloadString, 'utf8')
    .digest('hex');
}

/**
 * Verifies an incoming HMAC-SHA256 signature against the expected payload and secret.
 * Uses timingSafeEqual to guard against timing analysis attacks.
 *
 * @param {string} payloadString - The raw request body as received.
 * @param {string} receivedSignature - The value from the X-Webhook-Signature header.
 * @param {string} secret - The shared secret key.
 * @returns {boolean} True if signature is valid, false otherwise.
 */
export function verifySignature(payloadString, receivedSignature, secret) {
  if (!receivedSignature || !secret) {
    return false;
  }

  try {
    const expectedSignature = generateSignature(payloadString, secret);
    const expectedBuf = Buffer.from(expectedSignature, 'hex');
    const receivedBuf = Buffer.from(receivedSignature, 'hex');

    if (expectedBuf.length !== receivedBuf.length) {
      return false;
    }

    return crypto.timingSafeEqual(expectedBuf, receivedBuf);
  } catch {
    return false;
  }
}
