import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

/**
 * Initializes and configures the SQLite database.
 * Creates tables and indexes if they do not exist.
 *
 * @param {string} dbPath - File path to SQLite database or ':memory:'.
 * @returns {DatabaseSync} Configured DatabaseSync instance.
 */
export function initDatabase(dbPath = 'data/webhooks.db') {
  if (dbPath !== ':memory:') {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new DatabaseSync(dbPath);

  // Enable WAL mode for file databases for concurrent reads/writes
  if (dbPath !== ':memory:') {
    db.exec('PRAGMA journal_mode = WAL;');
  }
  db.exec('PRAGMA foreign_keys = ON;');

  // Create events table
  db.exec(`
    CREATE TABLE IF NOT EXISTS events (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      payload TEXT NOT NULL,
      webhook_url TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('pending', 'delivered', 'failed', 'dead')),
      retry_count INTEGER NOT NULL DEFAULT 0,
      next_retry_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_events_status_next_retry ON events(status, next_retry_at);
    CREATE INDEX IF NOT EXISTS idx_events_created_at ON events(created_at DESC);

    CREATE TABLE IF NOT EXISTS attempts (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
      attempt_number INTEGER NOT NULL,
      attempted_at TEXT NOT NULL,
      http_status INTEGER,
      outcome TEXT NOT NULL CHECK(outcome IN ('success', 'failed')),
      error_message TEXT,
      response_time_ms INTEGER,
      FOREIGN KEY (event_id) REFERENCES events(id)
    );

    CREATE INDEX IF NOT EXISTS idx_attempts_event_id ON attempts(event_id, attempt_number ASC);
  `);

  return db;
}
